﻿using System;

namespace StaticConstructorApp
{
    class StaticConstructor
    {
        static int staticWithInitializer = 100;
        static int staticWithNoIntializer;
        StaticConstructor()
        {
            staticWithNoIntializer = staticWithInitializer + 100;
        }
        public static void PrintStaticVariable()
        {
            Console.WriteLine("field 1 = {0}, field 2 = {1}", staticWithInitializer, staticWithNoIntializer);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            StaticConstructor.PrintStaticVariable();
        }
    }
}
