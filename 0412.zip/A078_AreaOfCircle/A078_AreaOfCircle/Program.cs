﻿using System;

namespace A078_AreaOfCircle
{
    class Program
    {
        static void Main(string[] args)
        {
            for (double r = 1; r <= 10; r++)
                Console.WriteLine("Area of cicle with radius {0,2} = {1,7:F2}", r, AreaOfCircle(r));
        }
        static double AreaOfCircle(double r)
        {
            return Math.PI * r * r;
        }
    }
}
