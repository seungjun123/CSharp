﻿using System;

namespace A096_LinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
