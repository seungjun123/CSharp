﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A122_LinqToList
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> IstData = new List<int> { 123, 456, 132, 96, 13, 465, 321 };
            Print("Data : ", IstData);

            List<int> IstOdd = new List<int>();
            IstOdd = SelectOddAndSort(IstData);
            Print("Ordered Odd : ", IstOdd);

            int[] arrEven;
            arrEven = SelectEvenAndSort(IstData);
            Print("Ordered Even : ", arrEven);
        }

        

        private static List<int> SelectOddAndSort(List<int> IstData)
        {
            return (from item in IstData
                    where item % 2 == 0
                    orderby item
                    select item).ToArray<int>();
        }
        private static int[] SelectEvenAndSort(List<int> istData)
        {
            return (from item in istData
                    where item % 2 == 0
                    orderby item
                    select item).ToArray<int>();
        }
        private static void Print(string s, IEnumerable<int> data)
        {
            Console.WriteLine(s);
            foreach (var i in data)
                Console.Write(" " + i);
            Console.WriteLine();
        }
    }
}
