﻿using System;

namespace BoundedGenericApp
{
    class GenericType<T> where T : SystemException
    {
        private T value;
        public GenericType(T v)
        {
            value = v;
        }
        public override string ToString()
        {
            return "Type is " + value.GetType();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            GenericType<NullReferenceException> gNullEx = new GenericType<NullReferenceException>(new NullReferenceException());
            GenericType<IndexOutOfRangeException> gIndexEx = new GenericType<IndexOutOfRangeException>(new IndexOutOfRangeException());

            Console.WriteLine(gNullEx.ToString());
            Console.WriteLine(gIndexEx.ToString());
        }
    }
}
