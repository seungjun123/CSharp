﻿using System;

namespace VirtualMethodApp
{
    class BaseClass
    {
        virtual public void MethodA()
        {
            Console.WriteLine("Base MethodA");
        }
        virtual public void MethodB()
        {
            Console.WriteLine("Base MehtodB");
        }
        virtual public void MethodC()
        {
            Console.WriteLine("Base MehtodC");
        }
        class DerivedClss : BaseClass
        {
            new public void MethodA()
            {
                Console.WriteLine("Derived MethodA");
            }
            override public void MethodB()
            {
                Console.WriteLine("Derived MethodB");
            }
            public void MethodC()
            {
                Console.WriteLine("Derived MethodC");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            BaseClass s = new DerivedClss();
            s.MethodA();
            s.MethodB();
            s.MethodC();
        }
    }
}
