﻿using System;

namespace AddendumApp
{
    class BaseClass
    {
        public void MethodA()
        {
            Console.WriteLine("do BaseClass Task.");
        }
    }
    class DerivedClss : BaseClass
    { 
        new public void MethodA()
        {
            base.MethodA();
            Console.WriteLine("do DerviedClass Task.");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            DerivedClss obj = new DerivedClss();
            obj.MethodA();
        }
    }
}
